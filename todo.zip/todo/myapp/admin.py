from django.contrib import admin
from myapp.models import Task

# Register your models here.
admin.site.register(Task)
